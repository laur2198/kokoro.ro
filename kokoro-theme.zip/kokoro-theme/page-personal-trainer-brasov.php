<?php
/**
 * Template Name: Pillar — Personal Trainer Brașov
 *
 * Template hardcoded pentru pagina pilon SEO „personal-trainer-brasov".
 * Conținutul este sincronizat manual cu kokoro-theme/preview/personal-trainer-brasov.html.
 * Pentru update: edit aici sau pe preview, păstrați-le în sincron.
 *
 * Schema JSON-LD este randată inline (nu prin kokoro_render_jsonld_pillar
 * care țintește doar template-ul page-pillar.php generic).
 *
 * @package Kokoro
 */

get_header();
?>

<main id="content">

<!-- ============================================================
     SECTION 1: HERO
     ============================================================ -->
<section class="page-header">
  <div class="container">
    <div class="section-number">Antrenament 1-la-1 · Adrian Boglut</div>
    <h1>PERSONAL<br>TRAINER <em>BRAȘOV</em></h1>
    <p style="color: var(--color-gray); margin-top: var(--space-lg); max-width: 750px; line-height: 1.7; font-size: 1.0625rem;">
      Antrenament individualizat 1-la-1 cu <strong style="color: var(--color-white);">Adrian Boglut</strong>, vicecampion european U21 -62kg. Programe construite pe obiectivele dumneavoastră — slăbire, performanță sportivă, recuperare după accidentări sau pregătire fizică pentru competiții. Orar flexibil, evaluare gratuită.
    </p>

    <div style="display: flex; gap: var(--space-md); flex-wrap: wrap; margin-top: var(--space-2xl); align-items: center;">
      <a href="<?php echo esc_url(home_url('/inscriere/')); ?>" class="btn btn--primary btn--large">
        Programați Evaluarea Gratuită
      </a>
      <a href="tel:+40742037973" class="btn btn--outline btn--large">
        Sună Acum
      </a>
      <a href="tel:+40742037973" style="color: var(--color-accent); font-weight: 700; font-size: 1.125rem; margin-left: var(--space-md); white-space: nowrap; text-decoration: none;">
        📞 0742 037 973
      </a>
    </div>
  </div>
  <div class="page-header__number" aria-hidden="true">力</div>
</section>

<!-- ============================================================
     SECTION 2: INTRO
     ============================================================ -->
<section class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">01 — De ce personal trainer</div>
      <h2>ANTRENAMENT<br>FĂCUT <em>PENTRU DUMNEAVOASTRĂ</em></h2>
    </div>

    <div class="reveal" style="color: var(--color-gray); line-height: 1.9; font-size: 1.0625rem;">
      <p style="margin-bottom: var(--space-lg);">
        Diferența între o sală de fitness obișnuită și un personal trainer este simplă: <strong style="color: var(--color-white);">programul construit pentru dumneavoastră versus programul generic pentru toată lumea</strong>. La sală încercați să adaptați un program standard la corpul, obiectivele și limitările dumneavoastră personale. Cu un personal trainer, programul se adaptează la dumneavoastră — la istoricul de accidentări, la timpul disponibil, la motivația care vă ține sau vă slăbește, la viața reală.
      </p>
      <p style="margin-bottom: var(--space-lg);">
        La Kokoro Brașov, antrenamentele de personal training sunt conduse direct de <strong style="color: var(--color-white);">Adrian Boglut</strong> — vicecampion european U21 -62kg, antrenor cu 17 ani de experiență în pregătirea fizică pentru sportivi de performanță, dar și pentru oameni obișnuiți care vor să-și recâștige forma. Adrian a antrenat campioni mondiali și juniori la primele competiții, dar și manageri stresați care n-au făcut sport de la liceu. Diferența o face programul, nu sala.
      </p>
      <p>
        Veniți cu un obiectiv concret — să slăbiți 8 kilograme, să vă recuperați după operație, să intrați în formă pentru o competiție, să rezolvați o durere cronică de spate. Plecați cu un plan măsurabil, cu repere clare la 4, 8 și 12 săptămâni. Iar pe parcurs, veți avea pe cineva care urmărește fiecare ședință, ajustează programul când e nevoie și răspunde la întrebări tehnice direct, fără să citiți articole pe internet.
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 3: BENEFICII
     ============================================================ -->
<section class="section section--alt">
  <div class="container">
    <div class="section__header reveal">
      <div class="section-number">02 — Beneficii</div>
      <h2>CE OBȚINEȚI<br>CU UN <em>PERSONAL TRAINER</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); max-width: 700px; line-height: 1.7;">
        Un personal trainer nu este un lux — este o investiție care economisește timp, evită accidentări și produce rezultate vizibile. Iată ce primiți concret.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-xl);">
      <div class="reveal reveal-delay-1" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🎯</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Program 100% personalizat</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Construit după evaluarea fizică inițială, istoricul de accidentări, obiectivele dumneavoastră și timpul disponibil. Recalibrat la fiecare 4 săptămâni în funcție de progres.
        </p>
      </div>

      <div class="reveal reveal-delay-2" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">⏱️</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Eficiență de timp</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          O ședință de 60 de minute cu antrenor produce rezultate echivalente cu 2-3 ore de antrenament independent la sală. Niciun timp pierdut între aparate sau cu exerciții ineficiente.
        </p>
      </div>

      <div class="reveal reveal-delay-3" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🛡️</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Tehnică corectă, fără accidentări</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Antrenorul corectează în timp real fiecare repetare. Tehnica greșită învățată acasă din video se transformă în accidentări lombare sau de umăr — un lucru pe care nu vi-l permiteți.
        </p>
      </div>

      <div class="reveal reveal-delay-4" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">📊</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Măsurare reală a progresului</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Repere clare la 4, 8 și 12 săptămâni: greutate, perimetre, forță în exerciții cheie, rezistență cardio. Nu „mă simt mai bine" — date concrete pe care le puteți compara.
        </p>
      </div>

      <div class="reveal reveal-delay-1" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">💡</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Educație nutrițională de bază</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Fără antrenament dietetic, dar cu sfaturi pragmatice despre alimentație care susține obiectivele dumneavoastră. Ce să mâncați înainte și după ședință, cum să gestionați mesele când călătoriți, mituri demontate.
        </p>
      </div>

      <div class="reveal reveal-delay-2" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🤝</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Responsabilitate consistentă</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Pentru mulți, partea cea mai grea e să se prezinte la antrenament. O programare cu un antrenor concret, care vă așteaptă, schimbă fundamental ecuația. Probabilitatea de abandon scade dramatic.
        </p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 4: PENTRU CINE
     ============================================================ -->
<section class="section section--dark" id="pentru-cine">
  <div class="container">
    <div class="section__header reveal">
      <div class="section-number">03 — Pentru cine</div>
      <h2>4 TIPURI DE<br>PROGRAME <em>SPECIALIZATE</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); max-width: 700px; line-height: 1.7;">
        Personal training-ul la Kokoro acoperă patru categorii principale de obiective. Fiecare cu metodologie diferită, dar toate cu același nivel de individualizare.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-xl);">
      <div class="card reveal reveal-delay-1" style="padding: var(--space-2xl);">
        <div class="card__tag">Slăbire & Compoziție corporală</div>
        <h3 class="card__title" style="margin-top: var(--space-md);">PIERDERE <em>SĂNĂTOASĂ</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7; margin-top: var(--space-md);">
          Pentru oamenii care vor să piardă 5-20 kg într-un mod sustenabil — fără diete extreme. Combinăm antrenament metabolic cu sfaturi nutriționale practice. Repere realiste: 0.5-1 kg/săptămână constant, fără efect yo-yo.
        </p>
        <p style="color: var(--color-accent); font-weight: 700; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.05em; margin-top: var(--space-md);">
          Recomandat: 2-3 ședințe/săptămână
        </p>
      </div>

      <div class="card reveal reveal-delay-2" style="padding: var(--space-2xl); border-color: var(--color-accent);">
        <div class="card__tag">Performanță sportivă</div>
        <h3 class="card__title" style="margin-top: var(--space-md);">PREGĂTIRE <em>COMPETIȚII</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7; margin-top: var(--space-md);">
          Pentru sportivi care vor să-și împingă limitele — atleți, jucători de tenis, ciclismuri, trail runners. Antrenamente specifice sportului dumneavoastră, periodizare pe sezon competițional, recuperare optimă între eforturi.
        </p>
        <p style="color: var(--color-accent); font-weight: 700; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.05em; margin-top: var(--space-md);">
          Recomandat: 3-4 ședințe/săptămână
        </p>
      </div>

      <div class="card reveal reveal-delay-3" style="padding: var(--space-2xl);">
        <div class="card__tag">Recuperare după accidentări</div>
        <h3 class="card__title" style="margin-top: var(--space-md);">REVENIRE <em>SIGURĂ</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7; margin-top: var(--space-md);">
          Pentru cei care s-au refăcut după operație, accidentare sportivă sau problemă cronică (spate, genunchi, umăr). Antrenament gradual, focus pe stabilitate și mobilitate, în colaborare cu medicul și fizioterapeutul dacă este cazul.
        </p>
        <p style="color: var(--color-accent); font-weight: 700; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.05em; margin-top: var(--space-md);">
          Recomandat: 2 ședințe/săptămână
        </p>
      </div>

      <div class="card reveal reveal-delay-4" style="padding: var(--space-2xl);">
        <div class="card__tag">Wellness general</div>
        <h3 class="card__title" style="margin-top: var(--space-md);">SĂNĂTATE <em>DURABILĂ</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7; margin-top: var(--space-md);">
          Pentru cei care vor pur și simplu să fie mai sănătoși — energie pe parcursul zilei, postură mai bună, somn îmbunătățit, gestionare stres prin mișcare. Fără presiunea unor obiective competitive — focus pe consistență.
        </p>
        <p style="color: var(--color-accent); font-weight: 700; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.05em; margin-top: var(--space-md);">
          Recomandat: 1-2 ședințe/săptămână
        </p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 5: CUM SE DESFĂȘOARĂ O ȘEDINȚĂ
     ============================================================ -->
<section class="section section--alt">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">04 — Structura ședinței</div>
      <h2>CUM SE DESFĂȘOARĂ<br>O <em>ȘEDINȚĂ TIPICĂ</em></h2>
    </div>

    <div class="reveal" style="color: var(--color-bg); line-height: 1.9; font-size: 1.0625rem;">
      <p style="margin-bottom: var(--space-lg);">
        O ședință de personal training durează <strong>60 de minute</strong> și urmează o structură clară, dar flexibilă în funcție de obiectivele dumneavoastră și starea zilei (uneori veniți obosit, uneori plin de energie — programul se adaptează).
      </p>

      <div style="background: var(--color-white); border-left: 4px solid var(--color-accent); padding: var(--space-lg); border-radius: 4px; margin-bottom: var(--space-lg);">
        <p style="color: var(--color-accent); font-weight: 800; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: var(--space-sm);">⏱️ 0-10 minute</p>
        <p><strong>Check-in și încălzire</strong> — discuție scurtă (1-2 min) despre cum a fost săptămâna, somn, energie. Apoi încălzire dinamică adaptată antrenamentului din ziua respectivă.</p>
      </div>

      <div style="background: var(--color-white); border-left: 4px solid var(--color-accent); padding: var(--space-lg); border-radius: 4px; margin-bottom: var(--space-lg);">
        <p style="color: var(--color-accent); font-weight: 800; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: var(--space-sm);">⏱️ 10-25 minute</p>
        <p><strong>Lucru tehnic / forță</strong> — exerciții compuse (squat, deadlift, presa, tracțiuni etc.) cu corectare tehnică în timp real. Volumul și intensitatea calibrate la programul dumneavoastră.</p>
      </div>

      <div style="background: var(--color-white); border-left: 4px solid var(--color-accent); padding: var(--space-lg); border-radius: 4px; margin-bottom: var(--space-lg);">
        <p style="color: var(--color-accent); font-weight: 800; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: var(--space-sm);">⏱️ 25-45 minute</p>
        <p><strong>Lucru specific obiectivului</strong> — varies dramatic în funcție de program: condiționare metabolică (slăbire), exerciții specifice sportului (performanță), mobilitate și stabilitate (recuperare), antrenament functional (wellness).</p>
      </div>

      <div style="background: var(--color-white); border-left: 4px solid var(--color-accent); padding: var(--space-lg); border-radius: 4px; margin-bottom: var(--space-lg);">
        <p style="color: var(--color-accent); font-weight: 800; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: var(--space-sm);">⏱️ 45-55 minute</p>
        <p><strong>Cool-down + mobilitate</strong> — stretching activ și pasiv, lucru pe zonele tensionate identificate în antrenament. Această parte e adesea sărită la sală — aici nu.</p>
      </div>

      <div style="background: var(--color-white); border-left: 4px solid var(--color-accent); padding: var(--space-lg); border-radius: 4px; margin-bottom: var(--space-lg);">
        <p style="color: var(--color-accent); font-weight: 800; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: var(--space-sm);">⏱️ 55-60 minute</p>
        <p><strong>Debriefing și plan pentru data viitoare</strong> — feedback scurt: ce a mers bine, ce ajustăm, ce să faceți acasă între ședințe (mobilitate de 5 min de exemplu).</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 6: TESTIMONIALE
     ============================================================ -->
<section class="section section--dark">
  <div class="container">
    <div class="section__header reveal">
      <div class="section-number">05 — Părerile clienților</div>
      <h2>REZULTATE <em>REALE</em><br>DE LA OAMENI REALI</h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); max-width: 700px; line-height: 1.7;">
        Iată câteva mărturii reprezentative de la persoane care au făcut personal training cu Adrian Boglut la Kokoro Brașov.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-xl);">
      <div class="testimonial reveal reveal-delay-1">
        <div class="testimonial__stars">★★★★★</div>
        <p class="testimonial__text">
          „[DE COMPLETAT — testimonial real client 1: focus pe slăbire — kg pierdute, transformare în 3-6 luni, abordare sănătoasă fără diete extreme.]"
        </p>
        <div class="testimonial__author">[Nume Client 1]</div>
        <div class="testimonial__source">[ocupație], [vârstă] ani</div>
      </div>

      <div class="testimonial reveal reveal-delay-2">
        <div class="testimonial__stars">★★★★★</div>
        <p class="testimonial__text">
          „[DE COMPLETAT — testimonial real client 2: focus pe performanță sportivă — pregătire pentru competiție, rezultat concret obținut.]"
        </p>
        <div class="testimonial__author">[Nume Client 2]</div>
        <div class="testimonial__source">[sport practicat], [vârstă] ani</div>
      </div>

      <div class="testimonial reveal reveal-delay-3">
        <div class="testimonial__stars">★★★★★</div>
        <p class="testimonial__text">
          „[DE COMPLETAT — testimonial real client 3: focus pe recuperare — accidentare/operație depășită cu antrenament gradual sub supraveghere.]"
        </p>
        <div class="testimonial__author">[Nume Client 3]</div>
        <div class="testimonial__source">[ocupație], [vârstă] ani</div>
      </div>
    </div>

    <div class="reveal" style="text-align: center; margin-top: var(--space-2xl);">
      <p style="color: var(--color-gray); font-size: 0.9375rem;">
        ⭐ <strong style="color: var(--color-accent);">4.8/5</strong> pe Google · <strong style="color: var(--color-white);">97 recenzii</strong> de la cursanți, părinți și clienți personal training
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 7: FAQ
     ============================================================ -->
<section class="section section--alt" id="faq">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">06 — Întrebări frecvente</div>
      <h2>ÎNTREBĂRI<br><em>FRECVENTE</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); line-height: 1.7;">
        Răspunsuri la cele mai des întâlnite întrebări despre personal training. Pentru întrebări specifice obiectivelor dumneavoastră, sunați la <a href="tel:+40742037973" style="color: var(--color-accent);">0742 037 973</a>.
      </p>
    </div>

    <div class="kokoro-faq" style="display: flex; flex-direction: column; gap: var(--space-md);">
      <details class="reveal reveal-delay-1" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Cât costă o ședință de personal training la Kokoro Brașov?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Tarifele variază în funcție de pachetul ales (1 ședință vs pachet 10 vs abonament lunar). Pentru detalii actualizate consultați pagina <a href="<?php echo esc_url(home_url('/tarife/')); ?>" style="color: var(--color-accent);">Tarife</a> sau sunați la <a href="tel:+40742037973" style="color: var(--color-accent);">0742 037 973</a>. Prima ședință de evaluare este întotdeauna <strong>gratuită</strong>.
        </div>
      </details>

      <details class="reveal reveal-delay-2" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Ce trebuie să port la prima ședință?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Haine sport confortabile (legging-uri sau pantaloni de trening + tricou + adidași curați pentru interior), sticlă de apă, prosop mic. Dacă aveți investigații medicale recente (analize sânge, EKG) — aduceți-le pentru evaluarea inițială. Vestiare separate disponibile.
        </div>
      </details>

      <details class="reveal reveal-delay-3" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Sunt începător total — pot să vin?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          <strong>Absolut.</strong> Mulți dintre clienții noștri n-au mai făcut sport de ani de zile. Programul este construit exact pentru nivelul dumneavoastră — primele 2-3 săptămâni se concentrează pe tehnică simplă, mobilitate și obișnuirea cu efortul. Nu există presiunea de a „ține pasul" cu nimeni.
        </div>
      </details>

      <details class="reveal reveal-delay-4" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Cât de des să vin pentru rezultate vizibile?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Depinde de obiectiv: <strong>slăbire</strong> 2-3 ședințe/săptămână, <strong>performanță sportivă</strong> 3-4 ședințe/săptămână, <strong>recuperare</strong> 2 ședințe/săptămână, <strong>wellness general</strong> 1-2 ședințe/săptămână. Frecvența contează mai mult decât intensitatea — consistența pe 3+ luni produce transformarea reală.
        </div>
      </details>

      <details class="reveal reveal-delay-1" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Aveți și consultanță nutrițională?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Oferim <strong>sfaturi pragmatice</strong> bazate pe principii nutriționale solide — nu suntem însă dieteticieni licențiați. Pentru regimuri specifice (ex: după bypass gastric, diabet de tip 1, alergii alimentare complexe) vă recomandăm un nutriționist atestat. Putem colabora direct cu nutriționistul dumneavoastră dacă aveți unul.
        </div>
      </details>

      <details class="reveal reveal-delay-2" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Pot suspenda abonamentul în vacanță?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Da. Suspendarea pentru vacanțe sau perioade medicale este flexibilă — anunțați-ne în avans, ședințele neutilizate se reportează în luna următoare. Avem politici clare scrise în contract — nu există surprize.
        </div>
      </details>

      <details class="reveal reveal-delay-3" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Personal training-ul funcționează și pentru femei?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          <strong>Absolut.</strong> 50% dintre clienții noștri de personal training sunt femei. Programul se adaptează diferent în funcție de obiective (recompoziție corporală, tonifiere, postpartum, pregătire pentru maraton etc.) — dar metodologia rămâne aceeași: individualizare totală, rezultate măsurabile, accent pe sustenabilitate.
        </div>
      </details>

      <details class="reveal reveal-delay-4" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Care e diferența față de o sală obișnuită cu personal trainer?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          În sălile obișnuite, „personal trainer" este adesea un termen comercial — antrenori cu certificare scurtă, fără palmares sportiv real, care lucrează cu zeci de clienți simultan. La Kokoro, antrenamentul este condus direct de Adrian Boglut — vicecampion european cu 17 ani de experiență. Calitatea nu e comparabilă, dar nici prețul nu e cel mai mic — venim cu un raport echilibrat preț-valoare pentru oamenii care iau în serios obiectivele.
        </div>
      </details>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 8: LOCAȚIE
     ============================================================ -->
<section class="section section--dark" id="locatie">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">07 — Locație</div>
      <h2>UNDE NE <em>GĂSIȚI</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); line-height: 1.7;">
        Personal training-ul are loc la sediul Kokoro din <strong style="color: var(--color-white);">Str. Carpaților 60, Brașov</strong> — sală echipată profesional, vestiare separate, parcare în zonă.
      </p>
    </div>

    <div class="reveal" style="width: 100%; height: 400px; border-radius: 8px; overflow: hidden; border: 1px solid var(--color-gray-dark);">
      <iframe
        title="Hartă Kokoro Brașov Academy — Str. Carpaților 60"
        src="https://www.openstreetmap.org/export/embed.html?bbox=25.5787%2C45.6377%2C25.5987%2C45.6477&amp;layer=mapnik&amp;marker=45.6427%2C25.5887"
        style="width: 100%; height: 100%; border: 0;"
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        allowfullscreen
      ></iframe>
    </div>

    <p class="reveal" style="text-align: center; margin-top: var(--space-md); color: var(--color-gray); font-size: 0.9375rem;">
      <strong style="color: var(--color-white);">Str. Carpaților 60, 500269 Brașov</strong> ·
      <a href="https://www.google.com/maps/search/?api=1&amp;query=45.6427%2C25.5887" target="_blank" rel="noopener" style="color: var(--color-accent);">Deschide pe Google Maps →</a>
    </p>
  </div>
</section>

<!-- ============================================================
     SECTION 9: CTA FINAL
     ============================================================ -->
<section class="section section--accent">
  <div class="container" style="text-align: center;">
    <div class="reveal">
      <h2 style="color: var(--color-bg);">PRIMA ȘEDINȚĂ<br>ESTE <em>GRATUITĂ</em></h2>
      <p style="color: var(--color-bg); opacity: 0.85; margin: var(--space-lg) auto var(--space-2xl); max-width: 700px; line-height: 1.7;">
        Evaluarea inițială (60 min) include: discuție despre obiectivele dumneavoastră, evaluare fizică simplă, schiță de program și răspuns la toate întrebările. Plecați fie cu un plan, fie cu informații utile chiar dacă alegeți altceva — fără nicio obligație.
      </p>
      <div style="display: flex; gap: var(--space-md); justify-content: center; flex-wrap: wrap; align-items: center;">
        <a href="<?php echo esc_url(home_url('/inscriere/')); ?>" class="btn btn--large" style="background: var(--color-bg); color: var(--color-accent); border-color: var(--color-bg);">
          Programați Evaluarea Gratuită
        </a>
        <a href="tel:+40742037973" class="btn btn--outline btn--large" style="border-color: var(--color-bg); color: var(--color-bg);">
          📞 0742 037 973
        </a>
      </div>
      <p style="color: var(--color-bg); opacity: 0.7; margin-top: var(--space-xl); font-size: 0.9375rem;">
        Sau scrieți-ne la <a href="mailto:contact@kokoro.ro" style="color: var(--color-bg); font-weight: 700;">contact&#64;kokoro.ro</a>
      </p>
    </div>
  </div>
</section>

</main>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Service",
  "@id": "https://kokoro.ro/personal-trainer-brasov.html#service",
  "name": "Personal Training cu Adrian Boglut — Kokoro Brașov",
  "description": "Antrenament personal individualizat 1-la-1 cu Adrian Boglut, vicecampion european U21 -62kg. Programe specializate pentru slăbire, performanță sportivă, recuperare după accidentări și wellness general.",
  "url": "https://kokoro.ro/personal-trainer-brasov.html",
  "serviceType": "Personal Training",
  "category": "Fitness & Sports",
  "provider": {
    "@type": "Organization",
    "name": "Kokoro Brașov Academy",
    "@id": "https://kokoro.ro/#organization",
    "url": "https://kokoro.ro/"
  },
  "areaServed": {
    "@type": "City",
    "name": "Brașov"
  },
  "availableChannel": {
    "@type": "ServiceChannel",
    "serviceLocation": {
      "@type": "Place",
      "name": "Kokoro Brașov Academy",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Str. Carpaților 60",
        "addressLocality": "Brașov",
        "postalCode": "500269",
        "addressCountry": "RO"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 45.6427,
        "longitude": 25.5887
      }
    },
    "servicePhone": "+40742037973",
    "serviceUrl": "https://kokoro.ro/inscriere.html"
  },
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Programe Personal Training",
    "itemListElement": [
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Slăbire & Compoziție corporală",
          "description": "Pierdere sustenabilă 5-20 kg, 0.5-1 kg/săptămână, 2-3 ședințe/săptămână"
        }
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Pregătire Performanță Sportivă",
          "description": "Antrenament specific sportului, periodizare pe sezon competițional, 3-4 ședințe/săptămână"
        }
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Recuperare după Accidentări",
          "description": "Antrenament gradual post-operatie/accidentare, focus stabilitate și mobilitate, 2 ședințe/săptămână"
        }
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "Wellness General",
          "description": "Energie, postură, somn, gestionare stres prin mișcare, 1-2 ședințe/săptămână"
        }
      }
    ]
  },
  "provider_mention": {
    "@type": "Person",
    "name": "Adrian Boglut",
    "jobTitle": "Personal Trainer & Antrenor principal",
    "award": "Vicecampion European U21 -62kg"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Cât costă o ședință de personal training la Kokoro Brașov?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Tarifele variază în funcție de pachetul ales (1 ședință vs pachet 10 vs abonament lunar). Pentru detalii actualizate consultați pagina Tarife sau sunați la 0742 037 973. Prima ședință de evaluare este întotdeauna gratuită."
      }
    },
    {
      "@type": "Question",
      "name": "Ce trebuie să port la prima ședință de personal training?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Haine sport confortabile (legging-uri sau pantaloni de trening + tricou + adidași curați pentru interior), sticlă de apă, prosop mic. Dacă aveți investigații medicale recente (analize sânge, EKG) — aduceți-le pentru evaluarea inițială. Vestiare separate disponibile."
      }
    },
    {
      "@type": "Question",
      "name": "Sunt începător total — pot să vin la personal training?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Absolut. Mulți dintre clienții noștri n-au mai făcut sport de ani de zile. Programul este construit exact pentru nivelul dumneavoastră — primele 2-3 săptămâni se concentrează pe tehnică simplă, mobilitate și obișnuirea cu efortul. Nu există presiunea de a ține pasul cu nimeni."
      }
    },
    {
      "@type": "Question",
      "name": "Cât de des să vin la personal training pentru rezultate vizibile?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Depinde de obiectiv: slăbire 2-3 ședințe/săptămână, performanță sportivă 3-4 ședințe/săptămână, recuperare 2 ședințe/săptămână, wellness general 1-2 ședințe/săptămână. Frecvența contează mai mult decât intensitatea — consistența pe 3+ luni produce transformarea reală."
      }
    },
    {
      "@type": "Question",
      "name": "Aveți și consultanță nutrițională la personal training?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Oferim sfaturi pragmatice bazate pe principii nutriționale solide — nu suntem însă dieteticieni licențiați. Pentru regimuri specifice (ex: după bypass gastric, diabet de tip 1, alergii alimentare complexe) vă recomandăm un nutriționist atestat. Putem colabora direct cu nutriționistul dumneavoastră dacă aveți unul."
      }
    },
    {
      "@type": "Question",
      "name": "Pot suspenda abonamentul de personal training în vacanță?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Da. Suspendarea pentru vacanțe sau perioade medicale este flexibilă — anunțați-ne în avans, ședințele neutilizate se reportează în luna următoare. Avem politici clare scrise în contract — nu există surprize."
      }
    },
    {
      "@type": "Question",
      "name": "Personal training-ul funcționează și pentru femei?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Absolut. 50% dintre clienții noștri de personal training sunt femei. Programul se adaptează diferent în funcție de obiective (recompoziție corporală, tonifiere, postpartum, pregătire pentru maraton etc.) — dar metodologia rămâne aceeași: individualizare totală, rezultate măsurabile, accent pe sustenabilitate."
      }
    },
    {
      "@type": "Question",
      "name": "Care e diferența între Kokoro și o sală obișnuită cu personal trainer?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "În sălile obișnuite, personal trainer este adesea un termen comercial — antrenori cu certificare scurtă, fără palmares sportiv real, care lucrează cu zeci de clienți simultan. La Kokoro, antrenamentul este condus direct de Adrian Boglut — vicecampion european cu 17 ani de experiență."
      }
    }
  ]
}
</script>

<?php get_footer();
