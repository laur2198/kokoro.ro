<?php
/**
 * Template Name: FAQ — Întrebări Frecvente
 *
 * Template hardcoded pentru pagina pilon SEO „faq".
 * Conținutul este sincronizat manual cu kokoro-theme/preview/faq.html.
 * Pentru update: edit aici sau pe preview, păstrați-le în sincron.
 *
 * Schema JSON-LD este randată inline (nu prin kokoro_render_jsonld_pillar
 * care țintește doar template-ul page-pillar.php generic).
 *
 * @package Kokoro
 */

get_header();
?>

<main id="content">

<!-- ============================================================
     SECTION 1: HERO
     ============================================================ -->
<section class="page-header">
  <div class="container">
    <div class="section-number">FAQ · Întrebări Frecvente</div>
    <h1>ÎNTREBĂRI<br><em>FRECVENTE</em></h1>
    <p style="color: var(--color-gray); margin-top: var(--space-lg); max-width: 750px; line-height: 1.7; font-size: 1.0625rem;">
      Răspunsuri scurte și directe la întrebările pe care le-am primit cel mai des în ultimii ani — despre înscriere, programe, tarife, echipament, locație. Dacă nu găsiți răspunsul aici, ne puteți suna la <a href="tel:+40742037973" style="color: var(--color-accent); font-weight: 700;">0742 037 973</a> sau scrie la <a href="mailto:contact@kokoro.ro" style="color: var(--color-accent); font-weight: 700;">contact&#64;kokoro.ro</a>.
    </p>

    <div style="display: flex; gap: var(--space-md); flex-wrap: wrap; margin-top: var(--space-2xl); align-items: center;">
      <a href="#cat-generale" class="btn btn--outline btn--small">Generale</a>
      <a href="#cat-inscriere" class="btn btn--outline btn--small">Înscriere</a>
      <a href="#cat-copii" class="btn btn--outline btn--small">Pentru copii</a>
      <a href="#cat-femei" class="btn btn--outline btn--small">Pentru femei</a>
      <a href="#cat-adulti" class="btn btn--outline btn--small">Pentru adulți</a>
      <a href="#cat-tarife" class="btn btn--outline btn--small">Tarife & plată</a>
      <a href="#cat-practic" class="btn btn--outline btn--small">Practic</a>
    </div>
  </div>
  <div class="page-header__number" aria-hidden="true">問</div>
</section>

<!-- ============================================================
     SECTION 2: INTRO
     ============================================================ -->
<section class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">Despre acest FAQ</div>
      <h2>RĂSPUNSURI<br>FĂRĂ <em>OCOLIȘURI</em></h2>
    </div>

    <div class="reveal" style="color: var(--color-gray); line-height: 1.9; font-size: 1.0625rem;">
      <p style="margin-bottom: var(--space-lg);">
        Am compilat în această pagină cele 15 întrebări pe care le primim săptămânal de la părinți, femei interesate de autoapărare, sportivi care vor să se înscrie și oameni curioși despre Ju-Jitsu. Răspunsurile sunt scurte (60-120 cuvinte fiecare) și pragmatice — fără marketing, doar informația de care aveți nevoie ca să luați o decizie.
      </p>
      <p>
        Dacă întrebarea dumneavoastră nu apare aici, e probabil pentru că este foarte specifică (ex: <em>„fiul meu de 6 ani are scolioză — poate face Ju-Jitsu?"</em>). Pentru cazuri particulare, sunați-ne direct sau veniți la o ședință de probă gratuită — discutăm 10-15 minute înainte de antrenament și vă spunem onest dacă vă putem ajuta sau dacă vă recomandăm altceva.
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 3: GENERALE — DESPRE KOKORO
     ============================================================ -->
<section id="cat-generale" class="section section--alt">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">01 — Generale</div>
      <h2>DESPRE<br><em>KOKORO</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          1. Ce este Kokoro Brașov Academy?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Kokoro Brașov Academy este o academie de Ju-Jitsu și autoapărare fondată în 2008 de Adrian Boglut, vicecampion european U21 -62kg. Oferim programe pentru copii (de la 4 ani), adolescenți, femei (autoapărare) și adulți (Ju-Jitsu de performanță și personal training). Sediul este pe Strada Carpaților 60, Brașov, cu o sală dedicată de 200 mp, vestiare separate și echipament profesional. Avem peste 200 de cursanți activi și am format zeci de campioni naționali și internaționali în 17 ani de activitate.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          2. Cine este Adrian Boglut și de ce contează?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Adrian Boglut este fondatorul și antrenorul principal al academiei — vicecampion european U21 -62kg, multiplu campion național, cu 17 ani de experiență ca antrenor. Diferența contează pentru că în Brașov sunt mulți instructori cu o certificare scurtă, dar puțini cu palmares competițional real. Adrian a luptat la nivel internațional, știe ce înseamnă presiunea unei competiții și transmite mai departe o tehnică verificată în condiții reale, nu copiată de pe YouTube. Conduce direct antrenamentele de performanță și personal training.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          3. Ce programe oferiți?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Avem cinci programe principale: <strong style="color: var(--color-bg);">Ju-Jitsu Copii</strong> (4-15 ani, grupe pe vârste), <strong style="color: var(--color-bg);">Autoapărare Copii</strong> (anti-bullying, 7-14 ani), <strong style="color: var(--color-bg);">Autoapărare Femei</strong> (3 niveluri: începătoare, intermediare, avansate), <strong style="color: var(--color-bg);">Ju-Jitsu Adulți</strong> (de la începător la performanță) și <strong style="color: var(--color-bg);">Personal Training 1-la-1</strong> cu Adrian Boglut (slăbire, performanță, recuperare). Pentru detalii pe fiecare program, consultați pagina <a href="<?php echo esc_url(home_url('/discipline/')); ?>" style="color: var(--color-accent); font-weight: 700;">Discipline</a>.
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 4: ÎNSCRIERE & PRIMUL ANTRENAMENT
     ============================================================ -->
<section id="cat-inscriere" class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">02 — Înscriere</div>
      <h2>ÎNSCRIERE<br>&amp; <em>PRIMA ȘEDINȚĂ</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          4. Cum mă înscriu la Kokoro?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Există trei moduri: (1) <strong style="color: var(--color-bg);">Online</strong> — completați formularul de pe pagina <a href="<?php echo esc_url(home_url('/inscriere/')); ?>" style="color: var(--color-accent); font-weight: 700;">Înscriere</a> și vă contactăm în maxim 24h pentru a stabili prima ședință de probă. (2) <strong style="color: var(--color-bg);">Telefon</strong> — sunați la 0742 037 973 între L-V 16:00-21:00 sau S 10:00-14:00. (3) <strong style="color: var(--color-bg);">Direct la sală</strong> — veniți pe Strada Carpaților 60 cu 15 minute înainte de începerea unui antrenament. Înscrierea formală (contract + plată) se face după prima ședință de probă, nu înainte.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          5. Pot veni la o ședință gratuită de probă?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Da, întotdeauna. Prima ședință este gratuită și fără nicio obligație — pentru toate programele (copii, femei, adulți, personal training). Veniți, faceți antrenamentul real (nu o demonstrație fictivă), vă uitați la grupă, discutați cu antrenorul și apoi decideți. Dacă alegeți să nu vă înscrieți, plecați fără să datorați nimic. Pentru copii recomandăm părinților să rămână să asiste — nu vă deranjăm cu obligații, scopul e ca dumneavoastră și copilul să vă faceți o părere informată.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          6. Ce trebuie să aduc / port la prima ședință?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Pentru prima ședință de probă: haine sport confortabile (legging-uri sau pantaloni de trening + tricou cu mâneci scurte), papuci sau șlapi pentru drumul până la tatami (pe tatami se intră desculț), o sticlă de apă și un prosop mic. <strong style="color: var(--color-bg);">Nu aveți nevoie de kimono sau echipament special pentru prima dată</strong> — vi le procurăm noi după înscriere (kimono Ju-Jitsu costă 180-250 lei și se cumpără direct de la sală sau online). Vestiare separate disponibile pentru bărbați și femei.
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 5: PENTRU COPII
     ============================================================ -->
<section id="cat-copii" class="section section--alt">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">03 — Pentru copii</div>
      <h2>PROGRAME<br>PENTRU <em>COPII</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          7. De la ce vârstă poate veni copilul meu la Ju-Jitsu?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          De la <strong style="color: var(--color-bg);">4 ani împliniți</strong>, în grupa Mini-Samurai (4-7 ani). La această vârstă antrenamentul este 70% joc structurat, rostogoliri, jocuri de echilibru — tehnica reală vine treptat după 6-7 ani. Grupa 8-12 ani este cea mai populară — copilul are deja coordonarea necesară pentru tehnici complete (proiectări, prinderi la sol, autoapărare). Adolescenții (13-15 ani) lucrează tehnică completă și pot intra în grupa de competiție dacă doresc. Pentru detalii pe vârste vedeți pagina <a href="<?php echo esc_url(home_url('/ju-jitsu-copii-brasov/')); ?>" style="color: var(--color-accent); font-weight: 700;">Ju-Jitsu Copii Brașov</a>.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          8. Ju-Jitsu îi va face pe copii agresivi?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Nu — exact invers. Ju-Jitsu este un dōjō, adică un loc de disciplină și respect. Primul lucru pe care îl învață un copil la Kokoro este <strong style="color: var(--color-bg);">când să NU folosească ce a învățat</strong>. Regulamentul intern interzice strict folosirea tehnicilor în afara sălii (cu excepția autoapărării reale documentate). Copiii care fac arte marțiale sistematic au, conform unui meta-studiu publicat în <em>Adolescent Research Review</em> (2018), niveluri mai scăzute de agresivitate decât media — pentru că învață să-și gestioneze frustrarea pe tatami, nu pe cineva mai mic.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          9. Copilul meu este timid / hiperactiv / cu ADHD — e potrivit Ju-Jitsu?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          În experiența noastră, da — pentru toate trei profilurile. <strong style="color: var(--color-bg);">Timizii</strong> capătă încredere văzând că pot face lucruri pe care nu le credeau posibile (o cădere controlată, o priză, primul examen de centură). <strong style="color: var(--color-bg);">Hiperactivii</strong> au un cadru fizic clar pentru energie — se obosesc sănătos și dorm mai bine. <strong style="color: var(--color-bg);">Copiii cu ADHD</strong> beneficiază de structura repetitivă și de feedback-ul imediat (ai făcut tehnica corect / mai ai de lucru). Pentru cazuri specifice, discutați cu antrenorul înainte de înscriere — pot ajusta abordarea.
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 6: PENTRU FEMEI
     ============================================================ -->
<section id="cat-femei" class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">04 — Pentru femei</div>
      <h2>AUTOAPĂRARE<br>PENTRU <em>FEMEI</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          10. Sunt femeie, n-am făcut sport de 10 ani — pot începe autoapărare?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Da, fără excepție. Grupa de Începătoare este construită exact pentru acest profil — primele 4-6 săptămâni se concentrează pe <strong style="color: var(--color-bg);">familiarizare cu mișcarea, căderi controlate și tehnici simple de degajare</strong> (de la apucări de mână, de păr, de îmbrățișare). Nu există „nivel minim" de fitness pentru a începe — efortul se calibrează după capacitatea fiecăreia. Multe dintre cursantele noastre actuale au început după 35 sau 40 de ani, după sarcini sau perioade lungi fără sport. Detalii pe pagina <a href="<?php echo esc_url(home_url('/autoaparare-femei-brasov/')); ?>" style="color: var(--color-accent); font-weight: 700;">Autoapărare Femei Brașov</a>.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          11. Care e diferența între autoapărarea voastră și un curs de Krav Maga?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Krav Maga e un sistem de autoapărare militar israelian — eficient, dar construit pentru aplicare imediată în situații extreme și învățat în general în cursuri scurte (10-20 ședințe). Programul nostru, bazat pe <strong style="color: var(--color-bg);">Ju-Jitsu adaptat</strong>, este o practică continuă care construiește în paralel: tehnică reală, condiție fizică, încredere de sine, capacitate de a evalua o situație înainte de a reacționa. Krav Maga vă învață <em>ce să faceți dacă</em> — Ju-Jitsu vă învață <em>cum să nu ajungeți în acea situație și ce să faceți dacă totuși ajungeți</em>. Ambele sunt valide; alegerea depinde de obiective.
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 7: PENTRU ADULȚI / PERSONAL TRAINING
     ============================================================ -->
<section id="cat-adulti" class="section section--alt">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">05 — Pentru adulți</div>
      <h2>PERFORMANȚĂ<br>&amp; <em>PERSONAL TRAINING</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          12. Am 35+ ani — pot începe Ju-Jitsu de la zero?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Absolut. Grupa de Adulți acceptă începători indiferent de vârstă — cel mai vechi cursant activ are 58 de ani și a început la 51. Diferența față de o grupă de copii sau adolescenți este <strong style="color: var(--color-bg);">ritmul</strong>: progresia este mai gradată, accentul cade pe tehnică curată și prevenția accidentărilor, nu pe sparring intens din prima lună. După 6-12 luni, majoritatea cursanților fac sparring controlat. Dacă obiectivul dumneavoastră este competiția, putem discuta o tranziție către grupa de performanță — dar nu e obligatorie.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          13. Care e diferența între personal training la Kokoro și o sală obișnuită?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          În sălile de fitness obișnuite, „personal trainer" este adesea un termen comercial — antrenori cu certificare de 2-4 săptămâni, fără palmares competițional, care lucrează cu 5-10 clienți simultan. La Kokoro, antrenamentul de personal training este condus <strong style="color: var(--color-bg);">direct de Adrian Boglut</strong> — vicecampion european cu 17 ani de experiență, 1-la-1 (sau maxim 2 persoane în paralel dacă lucrați împreună). Programul este construit după evaluare individuală și recalibrat la fiecare 4 săptămâni. Detalii pe pagina <a href="<?php echo esc_url(home_url('/personal-trainer-brasov/')); ?>" style="color: var(--color-accent); font-weight: 700;">Personal Trainer Brașov</a>.
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     D8.2 INSERT POINT: Pentru copii + Pentru femei + Pentru adulți
     ============================================================ -->

<!-- ============================================================
     SECTION 8: TARIFE & PLATĂ
     ============================================================ -->
<section id="cat-tarife" class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">06 — Tarife</div>
      <h2>TARIFE<br>&amp; <em>PLATĂ</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          14. Cât costă antrenamentele lunare?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Tarifele variază în funcție de program și frecvență. <strong style="color: var(--color-bg);">Aplicăm reduceri</strong> pentru: frați și surori înscriși împreună, plată pe 3 sau 6 luni în avans, familii cu doi părinți cursanți. Pentru lista completă și actualizată consultați pagina <a href="<?php echo esc_url(home_url('/tarife/')); ?>" style="color: var(--color-accent); font-weight: 700;">Tarife</a> sau sunați la 0742 037 973. Nu există taxă de înscriere ascunsă — plătiți doar abonamentul lunar și, opțional, kimonoul (180-250 lei, o singură dată).
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          15. Pot suspenda abonamentul în vacanță sau perioade medicale?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Da. Politica noastră este flexibilă pentru situații reale: <strong style="color: var(--color-bg);">vacanțele de vară</strong> (iulie-august) — abonamentul se poate suspenda complet, anunțați-ne în iunie. <strong style="color: var(--color-bg);">Concedii medicale</strong> — suspendare pe baza adeverinței, ședințele neutilizate se reportează în luna următoare. <strong style="color: var(--color-bg);">Călătorii scurte</strong> (1-2 săptămâni) — fără reducere de abonament, dar putem programa ședințe suplimentare la întoarcere. Toate detaliile sunt scrise clar în contractul de înscriere — fără surprize.
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 9: PRACTIC — ECHIPAMENT, LOCAȚIE, VESTIARE
     ============================================================ -->
<section id="cat-practic" class="section section--alt">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">07 — Practic</div>
      <h2>ECHIPAMENT<br>&amp; <em>LOCAȚIE</em></h2>
    </div>

    <div class="reveal" style="display: flex; flex-direction: column; gap: var(--space-xl); margin-top: var(--space-xl);">

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          16. Unde este sala și cum ajung cu mașina / autobuzul?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Sediul este pe <strong style="color: var(--color-bg);">Strada Carpaților 60, Brașov 500269</strong>, în zona Centrul Civic. <strong style="color: var(--color-bg);">Cu mașina</strong> — parcare gratuită în fața sălii (8-10 locuri). <strong style="color: var(--color-bg);">Cu autobuzul</strong> — liniile 4, 17, 23 opresc în stația „Carpaților" la 100m. <strong style="color: var(--color-bg);">Cu mijloace electrice</strong> — stație de încărcare la 200m (Lidl Carpaților). Sala este la parter, intrare directă din stradă, accesibilă pentru persoanele cu cărucior. Pentru ruta exactă consultați harta de pe pagina <a href="<?php echo esc_url(home_url('/contact/')); ?>" style="color: var(--color-accent); font-weight: 700;">Contact</a>.
        </p>
      </article>

      <article style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-md); color: var(--color-bg);">
          17. Ce facilități are sala? Există vestiare, dușuri, locuri pentru părinți?
        </h3>
        <p style="color: var(--color-gray); line-height: 1.8;">
          Sala are <strong style="color: var(--color-bg);">200 mp tatami profesional</strong> (saltele de competiție, certificate IJF), două vestiare separate (bărbați / femei) cu dulapuri cu cheie, două dușuri cu apă caldă, toaletă accesibilă. Pentru părinți există o zonă de așteptare cu băncuțe și vizibilitate către sală — puteți rămâne să asistați la antrenamentul copilului, mai ales în primele săptămâni. Wi-Fi gratuit. Aer condiționat în sezonul cald. <strong style="color: var(--color-bg);">Apă rece</strong> disponibilă gratuit, dar recomandăm să aduceți propria sticlă (mediu, cost pentru noi).
        </p>
      </article>

    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 10: CTA FINAL
     ============================================================ -->
<section class="section section--accent">
  <div class="container" style="text-align: center;">
    <div class="reveal">
      <h2 style="color: var(--color-bg);">N-AȚI GĂSIT<br>RĂSPUNSUL <em>AICI?</em></h2>
      <p style="color: var(--color-bg); opacity: 0.85; margin: var(--space-lg) auto var(--space-2xl); max-width: 700px; line-height: 1.7;">
        Pentru întrebări specifice (caz medical particular, situație individuală, dubii despre program), sunați-ne direct sau veniți la o ședință de probă gratuită. Discutăm onest 10-15 minute înainte de antrenament și vă spunem dacă vă putem ajuta — fără obligație de înscriere.
      </p>
      <div style="display: flex; gap: var(--space-md); justify-content: center; flex-wrap: wrap; align-items: center;">
        <a href="<?php echo esc_url(home_url('/inscriere/')); ?>" class="btn btn--large" style="background: var(--color-bg); color: var(--color-accent); border-color: var(--color-bg);">
          Programați O Ședință De Probă
        </a>
        <a href="tel:+40742037973" class="btn btn--outline btn--large" style="border-color: var(--color-bg); color: var(--color-bg);">
          📞 0742 037 973
        </a>
      </div>
      <p style="color: var(--color-bg); opacity: 0.7; margin-top: var(--space-xl); font-size: 0.9375rem;">
        Sau scrieți-ne la <a href="mailto:contact@kokoro.ro" style="color: var(--color-bg); font-weight: 700;">contact&#64;kokoro.ro</a>
      </p>
    </div>
  </div>
</section>

</main>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "@id": "https://kokoro.ro/faq.html#faqpage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Ce este Kokoro Brașov Academy?",
      "acceptedAnswer": {"@type": "Answer", "text": "Kokoro Brașov Academy este o academie de Ju-Jitsu și autoapărare fondată în 2008 de Adrian Boglut, vicecampion european U21 -62kg. Oferim programe pentru copii (de la 4 ani), adolescenți, femei (autoapărare) și adulți (Ju-Jitsu de performanță și personal training). Sediul este pe Strada Carpaților 60, Brașov, cu o sală dedicată de 200 mp."}
    },
    {
      "@type": "Question",
      "name": "Cine este Adrian Boglut și de ce contează?",
      "acceptedAnswer": {"@type": "Answer", "text": "Adrian Boglut este fondatorul și antrenorul principal al academiei — vicecampion european U21 -62kg, multiplu campion național, cu 17 ani de experiență ca antrenor. Conduce direct antrenamentele de performanță și personal training."}
    },
    {
      "@type": "Question",
      "name": "Ce programe oferiți?",
      "acceptedAnswer": {"@type": "Answer", "text": "Avem cinci programe principale: Ju-Jitsu Copii (4-15 ani), Autoapărare Copii (anti-bullying, 7-14 ani), Autoapărare Femei (3 niveluri: începătoare, intermediare, avansate), Ju-Jitsu Adulți (de la începător la performanță) și Personal Training 1-la-1 cu Adrian Boglut."}
    },
    {
      "@type": "Question",
      "name": "Cum mă înscriu la Kokoro?",
      "acceptedAnswer": {"@type": "Answer", "text": "Există trei moduri: online prin formularul de pe pagina Înscriere, telefon la 0742 037 973 (L-V 16:00-21:00, S 10:00-14:00) sau direct la sală pe Strada Carpaților 60. Înscrierea formală se face după prima ședință de probă gratuită."}
    },
    {
      "@type": "Question",
      "name": "Pot veni la o ședință gratuită de probă?",
      "acceptedAnswer": {"@type": "Answer", "text": "Da, întotdeauna. Prima ședință este gratuită și fără obligație pentru toate programele. Faceți antrenamentul real, vă uitați la grupă, discutați cu antrenorul și apoi decideți. Pentru copii, părinții pot rămâne să asiste."}
    },
    {
      "@type": "Question",
      "name": "Ce trebuie să aduc la prima ședință?",
      "acceptedAnswer": {"@type": "Answer", "text": "Haine sport confortabile, papuci pentru drumul până la tatami (pe tatami se intră desculț), o sticlă de apă și un prosop mic. Nu aveți nevoie de kimono pentru prima dată — se procură după înscriere (180-250 lei). Vestiare separate disponibile."}
    },
    {
      "@type": "Question",
      "name": "De la ce vârstă poate veni copilul meu la Ju-Jitsu?",
      "acceptedAnswer": {"@type": "Answer", "text": "De la 4 ani împliniți, în grupa Mini-Samurai (4-7 ani). La această vârstă antrenamentul este 70% joc structurat. Grupa 8-12 ani lucrează tehnică completă, iar adolescenții (13-15) pot intra în grupa de competiție."}
    },
    {
      "@type": "Question",
      "name": "Ju-Jitsu îi va face pe copii agresivi?",
      "acceptedAnswer": {"@type": "Answer", "text": "Nu — exact invers. Ju-Jitsu este un dōjō, un loc de disciplină și respect. Primul lucru pe care îl învață un copil este când să NU folosească ce a învățat. Studiile (Adolescent Research Review 2018) arată că practicanții de arte marțiale au niveluri mai scăzute de agresivitate decât media."}
    },
    {
      "@type": "Question",
      "name": "Copilul meu este timid sau cu ADHD — e potrivit Ju-Jitsu?",
      "acceptedAnswer": {"@type": "Answer", "text": "Da, pentru ambele profiluri. Timizii capătă încredere văzând că pot face lucruri pe care nu le credeau posibile. Copiii cu ADHD beneficiază de structura repetitivă și de feedback-ul imediat. Pentru cazuri specifice, discutați cu antrenorul înainte de înscriere."}
    },
    {
      "@type": "Question",
      "name": "Sunt femeie, n-am făcut sport de 10 ani — pot începe autoapărare?",
      "acceptedAnswer": {"@type": "Answer", "text": "Da, fără excepție. Grupa de Începătoare este construită exact pentru acest profil — primele 4-6 săptămâni se concentrează pe familiarizare cu mișcarea, căderi controlate și tehnici simple de degajare. Multe cursante au început după 35-40 de ani."}
    },
    {
      "@type": "Question",
      "name": "Care e diferența între autoapărarea voastră și Krav Maga?",
      "acceptedAnswer": {"@type": "Answer", "text": "Krav Maga este un sistem militar israelian, eficient dar învățat în cursuri scurte (10-20 ședințe). Programul nostru bazat pe Ju-Jitsu adaptat este o practică continuă care construiește în paralel: tehnică, condiție fizică, încredere de sine și capacitate de evaluare a situațiilor."}
    },
    {
      "@type": "Question",
      "name": "Am 35+ ani — pot începe Ju-Jitsu de la zero?",
      "acceptedAnswer": {"@type": "Answer", "text": "Absolut. Cel mai vechi cursant activ are 58 de ani și a început la 51. Progresia este gradată, accentul cade pe tehnică curată și prevenția accidentărilor. După 6-12 luni majoritatea cursanților fac sparring controlat."}
    },
    {
      "@type": "Question",
      "name": "Care e diferența între personal training la Kokoro și o sală obișnuită?",
      "acceptedAnswer": {"@type": "Answer", "text": "La Kokoro, antrenamentul de personal training este condus direct de Adrian Boglut — vicecampion european cu 17 ani experiență, 1-la-1. În sălile obișnuite, personal trainer este adesea termen comercial — antrenori cu certificare scurtă, fără palmares, lucrând cu mai mulți clienți simultan."}
    },
    {
      "@type": "Question",
      "name": "Cât costă antrenamentele lunare?",
      "acceptedAnswer": {"@type": "Answer", "text": "Tarifele variază în funcție de program și frecvență. Aplicăm reduceri pentru frați și surori înscriși împreună, plată pe 3 sau 6 luni în avans, familii cu doi părinți cursanți. Pentru lista actualizată consultați pagina Tarife sau sunați la 0742 037 973."}
    },
    {
      "@type": "Question",
      "name": "Pot suspenda abonamentul în vacanță sau perioade medicale?",
      "acceptedAnswer": {"@type": "Answer", "text": "Da. Vacanțele de vară (iulie-august) — abonamentul se poate suspenda complet. Concedii medicale — suspendare pe baza adeverinței. Călătorii scurte — putem programa ședințe suplimentare la întoarcere. Toate detaliile sunt scrise clar în contractul de înscriere."}
    },
    {
      "@type": "Question",
      "name": "Unde este sala și cum ajung?",
      "acceptedAnswer": {"@type": "Answer", "text": "Sediul este pe Strada Carpaților 60, Brașov 500269, în zona Centrul Civic. Cu mașina — parcare gratuită în fața sălii. Cu autobuzul — liniile 4, 17, 23 stația Carpaților la 100m. Sala este la parter, intrare directă din stradă."}
    },
    {
      "@type": "Question",
      "name": "Ce facilități are sala?",
      "acceptedAnswer": {"@type": "Answer", "text": "200 mp tatami profesional certificat IJF, două vestiare separate (bărbați/femei) cu dulapuri cu cheie, două dușuri cu apă caldă, toaletă accesibilă. Pentru părinți există zonă de așteptare cu vizibilitate către sală. Wi-Fi gratuit, aer condiționat."}
    }
  ]
}
</script>

<?php get_footer();
