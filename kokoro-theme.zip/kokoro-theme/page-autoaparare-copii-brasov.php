<?php
/**
 * Template Name: Pillar — Autoapărare Copii Brașov
 *
 * Template hardcoded pentru pagina pilon SEO „autoaparare-copii-brasov".
 * Conținutul este sincronizat manual cu kokoro-theme/preview/autoaparare-copii-brasov.html.
 * Pentru update: edit aici sau pe preview, păstrați-le în sincron.
 *
 * Schema JSON-LD este randată inline (nu prin kokoro_render_jsonld_pillar
 * care țintește doar template-ul page-pillar.php generic).
 *
 * @package Kokoro
 */

get_header();
?>

<main id="content">

<!-- ============================================================
     SECTION 1: HERO
     ============================================================ -->
<section class="page-header">
  <div class="container">
    <div class="section-number">Stop Bullying — Pentru Copii (4-15 ani)</div>
    <h1>AUTOAPĂRARE<br>PENTRU <em>COPII</em><br>ÎN BRAȘOV</h1>
    <p style="color: var(--color-gray); margin-top: var(--space-lg); max-width: 700px; line-height: 1.7; font-size: 1.0625rem;">
      Învățați-vă copilul să se apere fără să rănească. La Kokoro Brașov, autoapărarea pentru copii se bazează pe Ju-Jitsu autentic: <strong style="color: var(--color-white);">control, nu agresivitate</strong>. Tehnici care funcționează în viața reală, predate într-un mediu sigur și disciplinat.
    </p>

    <div style="display: flex; gap: var(--space-md); flex-wrap: wrap; margin-top: var(--space-2xl); align-items: center;">
      <a href="<?php echo esc_url(home_url('/inscriere/')); ?>" class="btn btn--primary btn--large">
        Antrenament Gratuit de Probă
      </a>
      <a href="tel:+40742037973" class="btn btn--outline btn--large">
        Sună Acum
      </a>
      <a href="tel:+40742037973" style="color: var(--color-accent); font-weight: 700; font-size: 1.125rem; margin-left: var(--space-md); white-space: nowrap; text-decoration: none;">
        📞 0742 037 973
      </a>
    </div>
  </div>
  <div class="page-header__number" aria-hidden="true">護</div>
</section>

<!-- ============================================================
     SECTION 2: INTRO
     ============================================================ -->
<section class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">01 — De ce autoapărare</div>
      <h2>AUTOAPĂRAREA PRIN<br>JU-JITSU <em>NON-VIOLENT</em></h2>
    </div>

    <div class="reveal" style="color: var(--color-gray); line-height: 1.9; font-size: 1.0625rem;">
      <p style="margin-bottom: var(--space-lg);">
        Ca părinte, vă doriți ca cei mici să fie capabili să se apere — dar fără să devină agresivi. <strong>Autoapărarea pentru copii la Kokoro Brașov</strong> este construită exact pe acest echilibru: copilul dumneavoastră învață să recunoască o situație de pericol, să o dezescaladeze prin postură și voce, iar dacă este necesar, să se apere fizic prin tehnici de Ju-Jitsu autentic care imobilizează atacatorul fără să-l rănească.
      </p>
      <p style="margin-bottom: var(--space-lg);">
        Spre deosebire de sistemele de autoapărare bazate pe lovituri (care învață copilul să răspundă cu violență), Ju-Jitsu-ul japonez tradițional pune accentul pe <strong style="color: var(--color-white);">controlul atacatorului</strong>: proiectări, imobilizări la sol, escape-uri din prinderi. Sunt tehnici care funcționează indiferent de mărimea sau forța adversarului — esențial pentru un copil care, statistic, va fi mai mic decât persoana care îl agresează.
      </p>
      <p>
        Iar partea cea mai importantă pe care o veți observa în primele luni nu este tehnica fizică — ci <strong>încrederea</strong>. Copilul care știe că poate să se apere nu mai trăiește cu frica zilnică a bullying-ului. Postura se schimbă, vocea devine mai sigură, iar agresorii — care selectează intuitiv victime aparent vulnerabile — îl ocolesc. Astfel, cea mai bună autoapărare devine să nu fii nevoit să o folosești niciodată.
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     [D3.2] DONE: Beneficii + Ce invata + Grupe varsta
     [D3.3] Testimoniale, FAQ, Locatie, CTA + Course/FAQPage schema
     ============================================================ -->

<!-- ============================================================
     SECTION 3: BENEFICII
     ============================================================ -->
<section class="section section--alt">
  <div class="container">
    <div class="section__header reveal">
      <div class="section-number">02 — Beneficii</div>
      <h2>CE OFERĂ COPILULUI<br>UN <em>CURS DE AUTOAPĂRARE</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); max-width: 700px; line-height: 1.7;">
        Autoapărarea adevărată nu înseamnă doar tehnici fizice — înseamnă o transformare interioară. Iată ce veți observa la copilul dumneavoastră în primele luni la Kokoro Brașov.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-xl);">
      <div class="reveal reveal-delay-1" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🛡️</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Protecție reală, nu teorie</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Tehnici testate timp de secole în Ju-Jitsu autentic, adaptate pentru copii. Funcționează indiferent de mărimea adversarului — esențial când copilul este mai mic decât atacatorul.
        </p>
      </div>

      <div class="reveal reveal-delay-2" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🧘</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Calm și control mental</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Antrenamentul dezvoltă capacitatea de a rămâne calm sub presiune. Copilul învață să respire, să gândească și să decidă rapid — abilități utile mult dincolo de tatami.
        </p>
      </div>

      <div class="reveal reveal-delay-3" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🚫</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Stop bullying-ului în școală</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Studiile arată că agresorii selectează intuitiv victime aparent vulnerabile. Copilul cu antrenament Ju-Jitsu emană siguranță — și astfel devine invizibil pentru bullying.
        </p>
      </div>

      <div class="reveal reveal-delay-4" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">💪</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Postură sigură pe sine</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Spatele drept, privire directă, voce calmă și fermă. Limbajul corporal al unui copil antrenat descurajează agresiunea înainte ca aceasta să înceapă.
        </p>
      </div>

      <div class="reveal reveal-delay-1" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">⚖️</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Discernământ etic</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Copilul învață <strong>când</strong> și <strong>cum</strong> să folosească tehnicile. Ju-Jitsu autentic include o componentă morală puternică: forța se folosește doar în apărare, niciodată pentru a iniția un conflict.
        </p>
      </div>

      <div class="reveal reveal-delay-2" style="padding: var(--space-xl); background: var(--color-white); border-left: 4px solid var(--color-accent); border-radius: 4px;">
        <div style="font-size: 2.5rem; line-height: 1; margin-bottom: var(--space-md);">🥋</div>
        <h3 style="font-family: var(--font-heading); font-weight: 800; font-size: 1.25rem; margin-bottom: var(--space-sm);">Disciplină + Autoapărare</h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Spre deosebire de cursurile scurte de „self-defense", aici copilul primește un sistem complet care formează caracterul: disciplină, respect, perseverență — alături de tehnică reală de protecție.
        </p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 4: CE ÎNVAȚĂ COPILUL
     ============================================================ -->
<section class="section section--dark">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">03 — Curriculum</div>
      <h2>CE VA ÎNVĂȚA<br><em>COPILUL DUMNEAVOASTRĂ</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); line-height: 1.7;">
        Programul nostru de autoapărare combină prevenția (cea mai importantă) cu tehnica fizică. Ordinea este intenționată — întâi prevenirea, apoi reacția.
      </p>
    </div>

    <ul class="reveal" style="list-style: none; padding: 0; margin: 0;">
      <li style="padding: var(--space-md) 0; border-bottom: 1px solid var(--color-gray-dark); color: var(--color-white); font-size: 1.0625rem; display: flex; align-items: flex-start; gap: var(--space-md);">
        <span aria-hidden="true" style="color: var(--color-accent); font-weight: 900; font-size: 1.25rem; flex-shrink: 0;">▸</span>
        <span><strong>Citirea limbajului corporal</strong> — cum să recunoască o persoană care reprezintă pericol înainte ca aceasta să acționeze.</span>
      </li>
      <li style="padding: var(--space-md) 0; border-bottom: 1px solid var(--color-gray-dark); color: var(--color-white); font-size: 1.0625rem; display: flex; align-items: flex-start; gap: var(--space-md);">
        <span aria-hidden="true" style="color: var(--color-accent); font-weight: 900; font-size: 1.25rem; flex-shrink: 0;">▸</span>
        <span><strong>Dezescaladarea verbală</strong> — postura și vocea de tip „nu mă atinge", răspunsuri ferme dar non-agresive.</span>
      </li>
      <li style="padding: var(--space-md) 0; border-bottom: 1px solid var(--color-gray-dark); color: var(--color-white); font-size: 1.0625rem; display: flex; align-items: flex-start; gap: var(--space-md);">
        <span aria-hidden="true" style="color: var(--color-accent); font-weight: 900; font-size: 1.25rem; flex-shrink: 0;">▸</span>
        <span><strong>Escape-uri din prinderi</strong> — eliberare din apucări de încheietură, haine, păr sau gât. Tehnici simple și eficiente.</span>
      </li>
      <li style="padding: var(--space-md) 0; border-bottom: 1px solid var(--color-gray-dark); color: var(--color-white); font-size: 1.0625rem; display: flex; align-items: flex-start; gap: var(--space-md);">
        <span aria-hidden="true" style="color: var(--color-accent); font-weight: 900; font-size: 1.25rem; flex-shrink: 0;">▸</span>
        <span><strong>Imobilizări la sol</strong> — controlul atacatorului fără a-l răni, până la sosirea unui adult sau a salvării.</span>
      </li>
      <li style="padding: var(--space-md) 0; border-bottom: 1px solid var(--color-gray-dark); color: var(--color-white); font-size: 1.0625rem; display: flex; align-items: flex-start; gap: var(--space-md);">
        <span aria-hidden="true" style="color: var(--color-accent); font-weight: 900; font-size: 1.25rem; flex-shrink: 0;">▸</span>
        <span><strong>Cădere sigură (ukemi)</strong> — abilitate fundamentală care protejează de leziuni dacă este împins sau cade accidental.</span>
      </li>
      <li style="padding: var(--space-md) 0; border-bottom: 1px solid var(--color-gray-dark); color: var(--color-white); font-size: 1.0625rem; display: flex; align-items: flex-start; gap: var(--space-md);">
        <span aria-hidden="true" style="color: var(--color-accent); font-weight: 900; font-size: 1.25rem; flex-shrink: 0;">▸</span>
        <span><strong>Răspuns la bullying verbal</strong> — strategii dovedite pentru școală: cum să nu reacționeze emoțional, când și cum să ceară ajutor adultului.</span>
      </li>
    </ul>

    <div class="reveal" style="margin-top: var(--space-xl); padding: var(--space-lg); background: var(--color-bg-card); border-left: 4px solid var(--color-accent); border-radius: 4px;">
      <p style="color: var(--color-white); line-height: 1.7;">
        <strong>Important:</strong> Antrenorii noștri repetă constant că <em>cea mai bună tehnică este cea pe care nu trebuie să o folosești niciodată</em>. Prevenția stă întotdeauna deasupra reacției.
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 5: GRUPE DE VÂRSTĂ
     ============================================================ -->
<section class="section section--alt">
  <div class="container">
    <div class="section__header reveal">
      <div class="section-number">04 — Grupe</div>
      <h2>PROGRAMUL <em>PE VÂRSTE</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); max-width: 700px; line-height: 1.7;">
        Autoapărarea se predă diferit la fiecare vârstă. Un copil de 5 ani învață să spună „nu" și să caute un adult; un adolescent învață tehnici reale de control fizic.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-xl);">
      <div class="card reveal reveal-delay-1" style="padding: var(--space-2xl);">
        <div class="card__tag">Copii 4-7 ani</div>
        <p style="color: var(--color-accent); font-weight: 700; margin: var(--space-md) 0; font-size: 0.9375rem;">
          Conștientizare prin joc
        </p>
        <h3 class="card__title" style="margin-bottom: var(--space-md);">PRIMUL <em>NIVEL</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Cum recunoaște o situație periculoasă, cum cere ajutor, cum spune „nu" cu fermitate. Tehnicile fizice sunt minime — accentul cade pe încredere și obișnuirea cu atingerea controlată în Ju-Jitsu.
        </p>
      </div>

      <div class="card reveal reveal-delay-2" style="padding: var(--space-2xl); border-color: var(--color-accent);">
        <div class="card__tag">Copii 8-12 ani</div>
        <p style="color: var(--color-accent); font-weight: 700; margin: var(--space-md) 0; font-size: 0.9375rem;">
          Tehnică + prevenție bullying
        </p>
        <h3 class="card__title" style="margin-bottom: var(--space-md);">VÂRSTA <em>CRUCIALĂ</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Statistic, cea mai expusă vârstă la bullying școlar. Învață escape-uri, imobilizări de bază și — esențial — strategii pentru bullying-ul verbal cu colegii. Antrenorul colaborează cu părinții pentru cazuri concrete.
        </p>
      </div>

      <div class="card reveal reveal-delay-3" style="padding: var(--space-2xl);">
        <div class="card__tag">Adolescenți 13-15 ani</div>
        <p style="color: var(--color-accent); font-weight: 700; margin: var(--space-md) 0; font-size: 0.9375rem;">
          Autoapărare reală
        </p>
        <h3 class="card__title" style="margin-bottom: var(--space-md);">NIVEL <em>AVANSAT</em></h3>
        <p style="color: var(--color-gray); line-height: 1.7;">
          Tehnici complete pentru situații reale — agresor adult, atac surpriză, multipli adversari. Incluzând discuții deschise despre situații specifice de risc pentru adolescenți (ieșit seara, transport public, etc.).
        </p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 6: TESTIMONIALE PĂRINȚI
     ============================================================ -->
<section class="section section--dark">
  <div class="container">
    <div class="section__header reveal">
      <div class="section-number">05 — Părerile părinților</div>
      <h2>POVEȘTI DE LA<br>PĂRINȚII <em>NOȘTRI</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); max-width: 700px; line-height: 1.7;">
        Schimbările pe care le vedeți la copil în primele luni sunt vizibile mai întâi acasă: postura mai dreaptă, vocea mai sigură, lipsa fricii de a merge la școală.
      </p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-xl);">
      <div class="testimonial reveal reveal-delay-1">
        <div class="testimonial__stars">★★★★★</div>
        <p class="testimonial__text">
          „[DE COMPLETAT — testimonial real părinte 1: focus pe schimbarea în comportamentul copilului la școală — bullying a încetat, postură mai sigură.]"
        </p>
        <div class="testimonial__author">[Nume Părinte 1]</div>
        <div class="testimonial__source">mama lui [Nume copil], [vârstă] ani</div>
      </div>

      <div class="testimonial reveal reveal-delay-2">
        <div class="testimonial__stars">★★★★★</div>
        <p class="testimonial__text">
          „[DE COMPLETAT — testimonial real părinte 2: copil timid care a câștigat încredere în sine, accent pe componenta non-violentă.]"
        </p>
        <div class="testimonial__author">[Nume Părinte 2]</div>
        <div class="testimonial__source">tatăl lui [Nume copil], [vârstă] ani</div>
      </div>

      <div class="testimonial reveal reveal-delay-3">
        <div class="testimonial__stars">★★★★★</div>
        <p class="testimonial__text">
          „[DE COMPLETAT — testimonial real părinte 3: situație concretă în care copilul a evitat un conflict prin dezescaladare verbală învățată la Kokoro.]"
        </p>
        <div class="testimonial__author">[Nume Părinte 3]</div>
        <div class="testimonial__source">mama lui [Nume copil], [vârstă] ani</div>
      </div>
    </div>

    <div class="reveal" style="text-align: center; margin-top: var(--space-2xl);">
      <p style="color: var(--color-gray); font-size: 0.9375rem;">
        ⭐ <strong style="color: var(--color-accent);">4.8/5</strong> pe Google · <strong style="color: var(--color-white);">97 recenzii</strong> de la părinți din Brașov
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 7: FAQ — ÎNTREBĂRI FRECVENTE
     ============================================================ -->
<section class="section section--alt" id="faq">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">06 — Întrebări frecvente</div>
      <h2>ÎNTREBĂRI<br><em>FRECVENTE</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); line-height: 1.7;">
        Răspunsuri la cele mai des întâlnite întrebări ale părinților despre cursul de autoapărare. Pentru situații specifice, sunați la <a href="tel:+40742037973" style="color: var(--color-accent);">0742 037 973</a>.
      </p>
    </div>

    <div class="kokoro-faq" style="display: flex; flex-direction: column; gap: var(--space-md);">
      <details class="reveal reveal-delay-1" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>De la ce vârstă pot să-mi înscriu copilul la autoapărare?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          De la <strong>4 ani</strong>. La această vârstă antrenamentul este aproape în întregime ludic — copilul învață să spună „nu", să ceară ajutor unui adult și să se obișnuiască cu atingerea controlată. Tehnicile fizice serioase apar treptat de la 7-8 ani.
        </div>
      </details>

      <details class="reveal reveal-delay-2" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Cursul îl va face pe copilul meu mai agresiv?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          <strong>Dimpotrivă.</strong> Disciplina Ju-Jitsu învață copilul <em>când să NU folosească tehnica</em>. Codul moral al artelor marțiale tradiționale interzice agresiunea — forța se folosește doar în apărare. În peste 17 ani de activitate, am observat constant că Ju-Jitsu calmează copiii agresivi și îi face mai sociabili pe cei timizi.
        </div>
      </details>

      <details class="reveal reveal-delay-3" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Funcționează și pentru copii timizi sau introvertiți?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Foarte bine. Copilul timid câștigă încredere progresiv, în pași mici și siguri. Antrenorii știu că nu împing copiii dincolo de zona lor de confort prematur — fiecare avansează în ritmul propriu. Mulți părinți ne spun că schimbarea de comportament a copilului timid este vizibilă încă din luna a doua.
        </div>
      </details>

      <details class="reveal reveal-delay-4" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Funcționează și pentru fete?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          <strong>Absolut</strong> — Ju-Jitsu este unul dintre cele mai potrivite sisteme de autoapărare pentru fete. Tehnicile se bazează pe pârghii și controlul echilibrului, nu pe forța brută, deci funcționează indiferent de diferența de mărime. Avem grupe mixte și fete care antrenează aici de ani buni, inclusiv la nivel competițional.
        </div>
      </details>

      <details class="reveal reveal-delay-1" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Care este diferența față de un curs scurt de self-defense?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Un curs scurt (1-2 weekend-uri) îți oferă câteva tehnici izolate, dar nu construiește <strong>reflexul</strong>. În autoapărarea reală nu ai timp să gândești — corpul trebuie să reacționeze automat. Acest reflex se formează doar prin antrenament constant, săptămâni și luni. La Kokoro, autoapărarea este parte dintr-un sistem complet care formează caracterul, nu doar tehnica.
        </div>
      </details>

      <details class="reveal reveal-delay-2" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Cât durează până se văd rezultate concrete contra bullying-ului?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Schimbarea de postură și încredere apare în <strong>4-8 săptămâni</strong>. Tehnica fizică funcțională (escape-uri din prinderi de bază) — în <strong>3-4 luni</strong> de antrenament constant. Cel mai puternic efect anti-bullying este însă <em>preventiv</em>: agresorii încetează să mai vizeze copilul pentru că emană siguranță.
        </div>
      </details>

      <details class="reveal reveal-delay-3" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Copilul meu este deja victima bullying-ului — ce fac?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          Sunați-ne la <a href="tel:+40742037973" style="color: var(--color-accent);">0742 037 973</a> și veniți împreună cu copilul la o discuție. Nu este vorba doar de antrenament — implică și colaborare cu școala, suport emoțional pentru copil și strategii concrete adaptate situației. Avem experiență cu astfel de cazuri și vom evalua individual ce abordare e potrivită.
        </div>
      </details>

      <details class="reveal reveal-delay-4" style="background: var(--color-white); border: 1px solid rgba(13, 33, 55, 0.1); border-radius: 4px; padding: var(--space-md) var(--space-lg);">
        <summary style="cursor: pointer; font-weight: 700; color: var(--color-bg); font-size: 1.0625rem; list-style: none; display: flex; justify-content: space-between; align-items: center; gap: var(--space-md);">
          <span>Care este diferența între Ju-Jitsu și Krav Maga pentru copii?</span>
          <span aria-hidden="true" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.5rem;">+</span>
        </summary>
        <div style="color: var(--color-gray); line-height: 1.8; margin-top: var(--space-md); padding-top: var(--space-md); border-top: 1px solid rgba(13, 33, 55, 0.08);">
          <strong>Krav Maga</strong> este un sistem militar de autoapărare conceput pentru reacții rapide și eficiente împotriva atacatorilor adulți, în situații extreme. Pune accent pe lovituri puternice și neutralizarea agresorului. <strong>Ju-Jitsu autentic</strong>, în schimb, oferă un sistem mai complet pentru copii: include disciplină morală, control fără rănire (proiectări, imobilizări) și o dimensiune educațională clară. Pentru un copil care nu se află în pericol militar, dar care trebuie să gestioneze conflicte școlare zilnice, Ju-Jitsu oferă răspunsuri mai potrivite.
        </div>
      </details>
    </div>
  </div>
</section>

<!-- ============================================================
     SECTION 8: LOCAȚIE
     ============================================================ -->
<section class="section section--dark" id="locatie">
  <div class="container container--narrow">
    <div class="section__header reveal">
      <div class="section-number">07 — Locație</div>
      <h2>UNDE NE <em>GĂSIȚI</em></h2>
      <p style="color: var(--color-gray); margin-top: var(--space-md); line-height: 1.7;">
        Sala Kokoro este în <strong style="color: var(--color-white);">Str. Carpaților 60, Brașov</strong> — zonă centrală cu acces facil. Părinții pot urmări antrenamentul dintr-o zonă dedicată.
      </p>
    </div>

    <div class="reveal" style="width: 100%; height: 400px; border-radius: 8px; overflow: hidden; border: 1px solid var(--color-gray-dark);">
      <iframe
        title="Hartă Kokoro Brașov Academy — Str. Carpaților 60"
        src="https://www.openstreetmap.org/export/embed.html?bbox=25.5787%2C45.6377%2C25.5987%2C45.6477&amp;layer=mapnik&amp;marker=45.6427%2C25.5887"
        style="width: 100%; height: 100%; border: 0;"
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
        allowfullscreen
      ></iframe>
    </div>

    <p class="reveal" style="text-align: center; margin-top: var(--space-md); color: var(--color-gray); font-size: 0.9375rem;">
      <strong style="color: var(--color-white);">Str. Carpaților 60, 500269 Brașov</strong> ·
      <a href="https://www.google.com/maps/search/?api=1&amp;query=45.6427%2C25.5887" target="_blank" rel="noopener" style="color: var(--color-accent);">Deschide pe Google Maps →</a>
    </p>
  </div>
</section>

<!-- ============================================================
     SECTION 9: CTA FINAL
     ============================================================ -->
<section class="section section--accent">
  <div class="container" style="text-align: center;">
    <div class="reveal">
      <h2 style="color: var(--color-bg);">PROTEJAȚI<br>COPILUL <em>DUMNEAVOASTRĂ</em></h2>
      <p style="color: var(--color-bg); opacity: 0.85; margin: var(--space-lg) auto var(--space-2xl); max-width: 600px; line-height: 1.7;">
        Primul antrenament este <strong>gratuit, fără nicio obligație ulterioară</strong>. Vom contacta dumneavoastră în maxim 24 de ore pentru a stabili împreună grupa potrivită pentru copil.
      </p>
      <div style="display: flex; gap: var(--space-md); justify-content: center; flex-wrap: wrap; align-items: center;">
        <a href="<?php echo esc_url(home_url('/inscriere/')); ?>" class="btn btn--large" style="background: var(--color-bg); color: var(--color-accent); border-color: var(--color-bg);">
          Înscrie-te Acum
        </a>
        <a href="tel:+40742037973" class="btn btn--outline btn--large" style="border-color: var(--color-bg); color: var(--color-bg);">
          📞 0742 037 973
        </a>
      </div>
      <p style="color: var(--color-bg); opacity: 0.7; margin-top: var(--space-xl); font-size: 0.9375rem;">
        Sau scrieți-ne la <a href="mailto:contact@kokoro.ro" style="color: var(--color-bg); font-weight: 700;">contact&#64;kokoro.ro</a>
      </p>
    </div>
  </div>
</section>

</main>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Course",
  "name": "Autoapărare pentru Copii (4-15 ani) — Kokoro Brașov",
  "description": "Curs de autoapărare bazat pe Ju-Jitsu autentic, adaptat pentru copii 4-15 ani. Combină prevenția (citire limbaj corporal, dezescaladare verbală) cu tehnică fizică reală (escape-uri, imobilizări) pentru protecție împotriva bullying-ului și agresiunii. Accent pe control, nu agresivitate.",
  "url": "https://kokoro.ro/autoaparare-copii-brasov.html",
  "provider": {
    "@type": "Organization",
    "name": "Kokoro Brașov Academy",
    "@id": "https://kokoro.ro/#organization",
    "url": "https://kokoro.ro/"
  },
  "inLanguage": "ro",
  "courseMode": "in-person",
  "educationalLevel": "Beginner to Advanced",
  "audience": {
    "@type": "EducationalAudience",
    "audienceType": "Children aged 4-15"
  },
  "teaches": [
    "Citirea limbajului corporal",
    "Dezescaladarea verbală",
    "Escape-uri din prinderi",
    "Imobilizări la sol fără rănire",
    "Cădere sigură (ukemi)",
    "Răspuns la bullying verbal"
  ],
  "hasCourseInstance": {
    "@type": "CourseInstance",
    "courseMode": "in-person",
    "courseSchedule": {
      "@type": "Schedule",
      "repeatFrequency": "P1W",
      "byDay": ["Monday", "Wednesday", "Friday"]
    },
    "location": {
      "@type": "Place",
      "name": "Kokoro Brașov Academy",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Str. Carpaților 60",
        "addressLocality": "Brașov",
        "postalCode": "500269",
        "addressCountry": "RO"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 45.6427,
        "longitude": 25.5887
      }
    },
    "instructor": {
      "@type": "Person",
      "name": "Adrian Boglut",
      "jobTitle": "Antrenor principal",
      "award": "Vicecampion European U21 -62kg"
    }
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "De la ce vârstă pot să-mi înscriu copilul la autoapărare?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "De la 4 ani. La această vârstă antrenamentul este aproape în întregime ludic — copilul învață să spună „nu”, să ceară ajutor unui adult și să se obișnuiască cu atingerea controlată. Tehnicile fizice serioase apar treptat de la 7-8 ani."
      }
    },
    {
      "@type": "Question",
      "name": "Cursul îl va face pe copilul meu mai agresiv?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Dimpotrivă. Disciplina Ju-Jitsu învață copilul când să NU folosească tehnica. Codul moral al artelor marțiale tradiționale interzice agresiunea — forța se folosește doar în apărare. În peste 17 ani de activitate, am observat constant că Ju-Jitsu calmează copiii agresivi și îi face mai sociabili pe cei timizi."
      }
    },
    {
      "@type": "Question",
      "name": "Funcționează și pentru copii timizi sau introvertiți?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Foarte bine. Copilul timid câștigă încredere progresiv, în pași mici și siguri. Antrenorii știu că nu împing copiii dincolo de zona lor de confort prematur — fiecare avansează în ritmul propriu. Mulți părinți ne spun că schimbarea de comportament a copilului timid este vizibilă încă din luna a doua."
      }
    },
    {
      "@type": "Question",
      "name": "Funcționează și pentru fete?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Absolut — Ju-Jitsu este unul dintre cele mai potrivite sisteme de autoapărare pentru fete. Tehnicile se bazează pe pârghii și controlul echilibrului, nu pe forța brută, deci funcționează indiferent de diferența de mărime."
      }
    },
    {
      "@type": "Question",
      "name": "Care este diferența față de un curs scurt de self-defense?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Un curs scurt (1-2 weekend-uri) îți oferă câteva tehnici izolate, dar nu construiește reflexul. În autoapărarea reală nu ai timp să gândești — corpul trebuie să reacționeze automat. Acest reflex se formează doar prin antrenament constant, săptămâni și luni. La Kokoro, autoapărarea este parte dintr-un sistem complet care formează caracterul, nu doar tehnica."
      }
    },
    {
      "@type": "Question",
      "name": "Cât durează până se văd rezultate concrete contra bullying-ului?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Schimbarea de postură și încredere apare în 4-8 săptămâni. Tehnica fizică funcțională (escape-uri din prinderi de bază) — în 3-4 luni de antrenament constant. Cel mai puternic efect anti-bullying este însă preventiv: agresorii încetează să mai vizeze copilul pentru că emană siguranță."
      }
    },
    {
      "@type": "Question",
      "name": "Copilul meu este deja victima bullying-ului — ce fac?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Sunați la 0742 037 973 și veniți împreună cu copilul la o discuție. Nu este vorba doar de antrenament — implică și colaborare cu școala, suport emoțional pentru copil și strategii concrete adaptate situației. Avem experiență cu astfel de cazuri și vom evalua individual ce abordare e potrivită."
      }
    },
    {
      "@type": "Question",
      "name": "Care este diferența între Ju-Jitsu și Krav Maga pentru copii?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Krav Maga este un sistem militar de autoapărare conceput pentru reacții rapide și eficiente împotriva atacatorilor adulți, în situații extreme. Pune accent pe lovituri puternice și neutralizarea agresorului. Ju-Jitsu autentic, în schimb, oferă un sistem mai complet pentru copii: include disciplină morală, control fără rănire (proiectări, imobilizări) și o dimensiune educațională clară. Pentru un copil care nu se află în pericol militar, dar care trebuie să gestioneze conflicte școlare zilnice, Ju-Jitsu oferă răspunsuri mai potrivite."
      }
    }
  ]
}
</script>

<?php get_footer();
